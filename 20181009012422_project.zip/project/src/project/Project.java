/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Scanner;

/**
 *
 * @author DELL
 */
public class Project {
static String studentList[];
				
				static String students;
				
				static Scanner readInputFromUser;
			        public static void main(String[] args) {
			        
			        
			        	System.out.println("STUDENT ID: 1794858");  
					System.out.println("STUDENT NAME: SIRISHA MATTA");
					
					studentList = new String[10];
					studentList[0]="Jonathan";
					studentList[1]="Roxanne";
					studentList[2]="Jasmine";
					studentList[3]="Sophianne";
					studentList[4]="";
					studentList[5]="";
					studentList[6]="";
					studentList[7]="";
					studentList[8]="";
					studentList[9]="";
					
			        
					Project students  = new Project();
    Scanner readinputFromUser = new Scanner(System.in); 
					
					int option;
					while(true)
					{
						
						System.out.println("MAIN MENU:");
						System.out.println("1. Display The List");
						System.out.println("2. Insert An Element");
						System.out.println("3. Swap Two Element");
						System.out.println("4. Quit");
						System.out.println("\nYour Choice?");
						
						option = readinputFromUser.nextInt();
						
						
						switch(option)
						{
						case 1:System.out.println("LIST CONTENT");
								students.displayList();
								break;
						case 2:System.out.println("INSERT AN ELEMENT");
								students.displayList();
								System.out.println("");
								System.out.println("WHERE TO INSERT ELEMENT:");
								int positionToInsertName = readinputFromUser.nextInt();
								System.out.println("ENTER THE NAME:");
								String name = readinputFromUser.next();
								students.insertName(positionToInsertName, name);
						break;
						case 3:System.out.println("From Element ?");
								int initialPosition = readinputFromUser.nextInt() ;
								System.out.println("To Element ?");
								int nextPosition = readinputFromUser.nextInt();
								students.swapTwoElements(initialPosition-1, nextPosition-1);
								break;
						case 4:System.exit(0);
					
						
						}
						
						
					}	
					
				}
				
				
				
				public void displayList()
				{
					int i=1;
					for(String studentName: studentList)
					{
						System.out.println(i+". "+studentName);
						i++;
					}
					
					
				}
				
				public void insertName(int position, String name)
				{
					
					
					if(position==0 || position>=10)
					{
						System.out.println("Please Enter Valid Position");
						position = readInputFromUser.nextInt();
						insertName(position, name);
					}
					else if(name.equals(" ") || name.equals(null))
					{
						System.out.println("Please Enter Valid Name");
						name = readInputFromUser.next();
						insertName(position, name);
					}
					else
					{
						if(!studentList[position].equals(""))
						{
							System.out.println("There is already a name at this position, Please enter another positon to insert the name");
							position = readInputFromUser.nextInt();
							insertName(position, name);
							
						}
						else
						{
							studentList[position-1]=name;
							System.out.println("Value Insert Successfully");
							
						}
					}	
					
				}
				
				
				
				public void swapTwoElements(int initialPosition, int nextPosition)
				{
					String name = studentList[initialPosition];
					
					studentList[initialPosition] = studentList[nextPosition];
					
					studentList[nextPosition] = name;
					
					System.out.println("Elements are successfully swapped");
					
				}

			


			    


	
		


}